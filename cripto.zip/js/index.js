import "./module/menu.js";
import "./module/modal.js";
import "./module/about-us-tabs.js";
import "./module/exchange-rates.js";
import "./module/remark.js";
import { accodrion } from "./module/faq.js";

accodrion();
